package com.creatinine.tracker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Список напоминаний приходит из страницы: [{id,title,text,h,m,date?}]. Без date — каждый день. */
object Reminders {
    private const val PREF = "rem"

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    fun replaceAll(c: Context, json: String) {
        cancelAll(c)
        prefs(c).edit().putString("list", json).apply()
        scheduleAll(c)
    }

    fun scheduleAll(c: Context) {
        val arr = try { JSONArray(prefs(c).getString("list", "[]")) } catch (e: Exception) { JSONArray() }
        for (i in 0 until arr.length()) scheduleOne(c, arr.getJSONObject(i))
    }

    private fun cancelAll(c: Context) {
        val arr = try { JSONArray(prefs(c).getString("list", "[]")) } catch (e: Exception) { JSONArray() }
        val am = c.getSystemService(AlarmManager::class.java)
        for (i in 0 until arr.length()) am.cancel(pending(c, arr.getJSONObject(i)))
    }

    private fun pending(c: Context, o: JSONObject): PendingIntent {
        val id = o.getString("id")
        val it = Intent(c, ReminderReceiver::class.java).apply {
            data = Uri.parse("ck://rem/$id")
            putExtra("json", o.toString())
        }
        return PendingIntent.getBroadcast(
            c, id.hashCode(), it,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun nextTrigger(o: JSONObject): Long? {
        val h = o.getInt("h")
        val m = o.getInt("m")
        val now = System.currentTimeMillis()
        val c = Calendar.getInstance()
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        val date = o.optString("date", "")
        if (date.isNotEmpty()) {
            val p = date.split("-")
            c.set(p[0].toInt(), p[1].toInt() - 1, p[2].toInt(), h, m, 0)
            return if (c.timeInMillis > now) c.timeInMillis else null
        }
        c.set(Calendar.HOUR_OF_DAY, h)
        c.set(Calendar.MINUTE, m)
        if (c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun scheduleOne(c: Context, o: JSONObject) {
        val t = nextTrigger(o) ?: return
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pending(c, o)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
    }
}
