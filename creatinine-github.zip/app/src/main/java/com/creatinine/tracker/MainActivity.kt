package com.creatinine.tracker

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.*
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val hs by lazy { HealthSync(this) }
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var pendingDays = 14
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val hcPerm = registerForActivityResult(PermissionController.createRequestPermissionResultContract()) { g ->
        if (g.isNotEmpty()) doSync(pendingDays)
        else reply("no_permission", "Доступ не разрешён. Откройте Health Connect → Разрешения приложений → Контроль креатинина и включите доступ.")
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
        fileCb = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, ins ->
            val b = ins.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout() or WindowInsetsCompat.Type.ime()
            )
            v.setPadding(b.left, b.top, b.right, b.bottom)
            WindowInsetsCompat.CONSUMED
        }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { chooser.launch(p.createIntent()); true } catch (e: Exception) { fileCb = null; false }
            }
            override fun onJsAlert(v: WebView, u: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }.setOnCancelListener { r.cancel() }.show(); return true
            }
            override fun onJsConfirm(v: WebView, u: String, m: String, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("OK") { _, _ -> r.confirm() }
                    .setNegativeButton("Отмена") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show(); return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        Reminders.scheduleAll(this)
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    private fun reply(status: String, msg: String, days: JSONObject? = null) {
        val o = JSONObject().put("status", status).put("message", msg)
        if (days != null) o.put("days", days)
        val js = "window.onHealthResult&&window.onHealthResult(" + JSONObject.quote(o.toString()) + ")"
        runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun doSync(days: Int) {
        scope.launch {
            try {
                val data = withContext(Dispatchers.IO) { hs.read(days) }
                reply("ok", "", data)
            } catch (e: Exception) {
                reply("error", "Не удалось прочитать Health Connect: " + (e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private fun startSync(days: Int) {
        pendingDays = days
        when (HealthConnectClient.getSdkStatus(this)) {
            HealthConnectClient.SDK_UNAVAILABLE ->
                reply("unavailable", "Health Connect не поддерживается на этом телефоне.")
            HealthConnectClient.SDK_UNAVAILABLE_PROVIDER_UPDATE_REQUIRED ->
                reply("update", "Установите или обновите приложение Health Connect (кнопка «Health Connect»).")
            else -> scope.launch {
                val g = runCatching { hs.granted() }.getOrDefault(emptySet())
                if (g.any { it in HealthSync.CORE }) doSync(days)
                else hcPerm.launch(HealthSync.PERMS)
            }
        }
    }

    inner class Bridge {
        @JavascriptInterface fun syncHealth(days: Int) { runOnUiThread { startSync(days) } }

        @JavascriptInterface fun loadState(): String =
            try { File(filesDir, "state.json").readText() } catch (e: Exception) { "" }

        @JavascriptInterface fun saveState(json: String) {
            try {
                val tmp = File(filesDir, "state.tmp"); tmp.writeText(json)
                tmp.renameTo(File(filesDir, "state.json"))
            } catch (e: Exception) { }
        }

        @JavascriptInterface fun saveBackup(name: String, json: String): String = try {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/json")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: throw Exception("нет доступа")
            contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) }
            "ok"
        } catch (e: Exception) { e.message ?: "ошибка" }

        @JavascriptInterface fun setReminders(json: String) { Reminders.replaceAll(this@MainActivity, json) }

        @JavascriptInterface fun openHealthConnect() {
            runOnUiThread {
                try {
                    if (HealthConnectClient.getSdkStatus(this@MainActivity) == HealthConnectClient.SDK_AVAILABLE)
                        startActivity(Intent(HealthConnectClient.ACTION_HEALTH_CONNECT_SETTINGS))
                    else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.healthdata")))
                } catch (e: Exception) { }
            }
        }
    }
}
