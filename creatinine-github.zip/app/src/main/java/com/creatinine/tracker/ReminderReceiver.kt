package com.creatinine.tracker

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject

class ReminderReceiver : BroadcastReceiver() {
    @SuppressLint("MissingPermission")
    override fun onReceive(c: Context, i: Intent) {
        val o = try { JSONObject(i.getStringExtra("json") ?: return) } catch (e: Exception) { return }
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("reminders", "Напоминания", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(c, "reminders")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle(o.optString("title"))
            .setContentText(o.optString("text"))
            .setStyle(NotificationCompat.BigTextStyle().bigText(o.optString("text")))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try { NotificationManagerCompat.from(c).notify(o.getString("id").hashCode(), n) } catch (e: Exception) {}
        // ежедневные — ставим на завтра
        if (o.optString("date", "").isEmpty()) Reminders.scheduleOne(c, o)
    }
}
