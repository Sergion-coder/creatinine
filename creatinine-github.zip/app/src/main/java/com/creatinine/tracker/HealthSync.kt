package com.creatinine.tracker

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import org.json.JSONObject
import java.time.Duration
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class HealthSync(private val ctx: Context) {
    private val client: HealthConnectClient by lazy { HealthConnectClient.getOrCreate(ctx) }

    companion object {
        val PERMS = setOf(
            HealthPermission.getReadPermission(StepsRecord::class),
            HealthPermission.getReadPermission(HeartRateRecord::class),
            HealthPermission.getReadPermission(RestingHeartRateRecord::class),
            HealthPermission.getReadPermission(SleepSessionRecord::class),
            HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
            HealthPermission.getReadPermission(ExerciseSessionRecord::class)
        )
        val CORE = setOf(
            HealthPermission.getReadPermission(StepsRecord::class),
            HealthPermission.getReadPermission(HeartRateRecord::class),
            HealthPermission.getReadPermission(SleepSessionRecord::class)
        )
    }

    suspend fun granted(): Set<String> = client.permissionController.getGrantedPermissions()

    private suspend fun hrSamples(r: TimeRangeFilter): List<Long> {
        val res = ArrayList<Long>()
        var token: String? = null
        do {
            val resp = client.readRecords(
                ReadRecordsRequest(HeartRateRecord::class, r, pageSize = 5000, pageToken = token)
            )
            resp.records.forEach { rec -> rec.samples.forEach { res.add(it.beatsPerMinute) } }
            token = resp.pageToken
        } while (!token.isNullOrEmpty())
        return res
    }

    /** Минуты быстрой ходьбы: короткие записи шагов с темпом >= 60 шагов/мин. */
    private suspend fun walkMinutes(r: TimeRangeFilter): Double {
        var total = 0.0
        var token: String? = null
        do {
            val resp = client.readRecords(
                ReadRecordsRequest(StepsRecord::class, r, pageSize = 5000, pageToken = token)
            )
            resp.records.forEach { rec ->
                val min = Duration.between(rec.startTime, rec.endTime).seconds / 60.0
                if (min > 0.4 && min <= 30 && rec.count / min >= 60) total += min
            }
            token = resp.pageToken
        } while (!token.isNullOrEmpty())
        return total
    }

    suspend fun read(days: Int): JSONObject {
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val out = JSONObject()
        for (i in 0 until days) {
            val d = today.minusDays(i.toLong())
            val start = d.atStartOfDay(zone).toInstant()
            val end = if (i == 0) Instant.now() else d.plusDays(1).atStartOfDay(zone).toInstant()
            if (!end.isAfter(start)) continue
            val range = TimeRangeFilter.between(start, end)
            // сон относим к дню пробуждения: окно 18:00 вчера — 18:00 сегодня
            val sleepRange = TimeRangeFilter.between(
                d.minusDays(1).atTime(18, 0).atZone(zone).toInstant(),
                d.atTime(18, 0).atZone(zone).toInstant()
            )
            val day = JSONObject()

            val steps = runCatching {
                client.aggregate(AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), range))[StepsRecord.COUNT_TOTAL]
            }.getOrNull()
            if (steps != null && steps > 0) day.put("steps", steps)

            val kcal = runCatching {
                client.aggregate(AggregateRequest(setOf(TotalCaloriesBurnedRecord.ENERGY_TOTAL), range))[TotalCaloriesBurnedRecord.ENERGY_TOTAL]?.inKilocalories
            }.getOrNull()
            if (kcal != null && kcal > 0) day.put("kcal", kcal)

            val sleep = runCatching {
                client.aggregate(AggregateRequest(setOf(SleepSessionRecord.SLEEP_DURATION_TOTAL), sleepRange))[SleepSessionRecord.SLEEP_DURATION_TOTAL]?.toMinutes()
            }.getOrNull()
            if (sleep != null && sleep > 0) day.put("sleep", sleep)

            val hr = runCatching { hrSamples(range) }.getOrDefault(emptyList())
            if (hr.isNotEmpty()) day.put("hrAvg", hr.average())
            val rest = runCatching {
                client.aggregate(AggregateRequest(setOf(RestingHeartRateRecord.BPM_AVG), range))[RestingHeartRateRecord.BPM_AVG]
            }.getOrNull()
            if (rest != null && rest > 0) {
                day.put("rhr", rest)
            } else if (hr.size >= 20) {
                val s = hr.sorted()
                day.put("rhr", s.take(maxOf(1, s.size / 10)).average())
                day.put("rhrEst", true)
            }

            val ex = runCatching {
                client.aggregate(AggregateRequest(setOf(ExerciseSessionRecord.EXERCISE_DURATION_TOTAL), range))[ExerciseSessionRecord.EXERCISE_DURATION_TOTAL]?.toMinutes()?.toDouble()
            }.getOrNull() ?: 0.0
            val walk = runCatching { walkMinutes(range) }.getOrDefault(0.0)
            val active = maxOf(ex, walk)
            if (active > 0) day.put("active", active)

            if (day.length() > 0) out.put(d.toString(), day)
        }
        return out
    }
}
